class CreateDistancia < ActiveRecord::Migration[6.0]
  def change
    create_table :distancia do |t|
      t.string :origem
      t.string :destino
      t.bigint :distancia

      t.timestamps
    end
  end
end
