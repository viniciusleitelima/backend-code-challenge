class Distancium < ApplicationRecord
	validates :origem, :destino, :distancia, presence: true
end
