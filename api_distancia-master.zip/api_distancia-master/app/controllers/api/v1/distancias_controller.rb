class Api::V1::DistanciasController < Api::V1::ApiController
	
  before_action :set_distancia, only: [:show, :edit, :update]
 
  def index
    @distancias = Distancium.all
    render json: @distancias
  end
 
  def show
  	render json: @distancias
  end
  
  def update
    @distancia.update(distancia_params)
    if @distancia.save
      redirect_to action: :show, id: @distancia.id
    else
      render :edit, id: @distancia.id
    end
  end
  
  def create
  	 @distancias = Distancium.all
    render json: @distancias

    
  end
 
  private
 
  def distancia_params
    params.require(:distancia).permit(:origem, :destino, :distancia)

  end
 
  def set_distancia
    @distancia = distancia.find(params['id']) 
  end

end