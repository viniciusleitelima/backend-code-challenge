module Api::V1
 
 class ApiController < ApplicationController
 
 
 end
 
end